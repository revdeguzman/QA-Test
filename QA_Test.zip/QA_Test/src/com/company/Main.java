package com.company;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Main {

    public static void main(String[] args) {

        // Opening Chrome browser
        System.setProperty("webdriver.chrome.driver","C:\\Users\\pc1\\Documents\\Selenium\\chromedriver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        //URL
        driver.get("https://qaexam.forge99.com/properties");
        driver.manage().window().maximize();

        //Dropdown

        try {

            Thread.sleep(3000);                 //3000 milliseconds is three seconds.

        } catch(InterruptedException ex) {

            Thread.currentThread().interrupt();

        }

        Select drpdwn1 = new Select(driver.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[1]/article/div/div[1]/div[1]/div[1]/div[2]/select")));
        drpdwn1.selectByVisibleText("Price Descending");

        try {

            Thread.sleep(3000);                 //3000 milliseconds is three seconds.

        } catch(InterruptedException ex) {

            Thread.currentThread().interrupt();

        }

        Select drpdwn2 = new Select(driver.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[1]/article/div/div[1]/div[1]/div[1]/div[2]/select")));
        drpdwn2.selectByVisibleText("Price Ascending");

        try {

            Thread.sleep(3000);                 //3000 milliseconds is three seconds.

        } catch(InterruptedException ex) {

            Thread.currentThread().interrupt();

        }

        Select drpdwn3 = new Select(driver.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[1]/article/div/div[1]/div[1]/div[1]/div[2]/select")));
        drpdwn3.selectByVisibleText("Most Recent");

        try {

            Thread.sleep(3000);                 //3000 milliseconds is three seconds.

        } catch(InterruptedException ex) {

            Thread.currentThread().interrupt();

        }

        Select drpdwn4 = new Select(driver.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[1]/article/div/div[1]/div[1]/div[1]/div[2]/select")));
        drpdwn4.selectByVisibleText("A-Z");

        try {

            Thread.sleep(3000);                 //3000 milliseconds is three seconds.

        } catch(InterruptedException ex) {

            Thread.currentThread().interrupt();

        }

        Select drpdwn5 = new Select(driver.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[1]/article/div/div[1]/div[1]/div[1]/div[2]/select")));
        drpdwn5.selectByVisibleText("Z-A");

        try {

            Thread.sleep(3000);                 //3000 milliseconds is three seconds.

        } catch(InterruptedException ex) {

            Thread.currentThread().interrupt();

        }

        driver.close();
    }
}
